import React from 'react'

const ErrorPage = () => {
  return (
    <div className='container mt-5'>
      <h1 className="text-center">
        Error 404 : Page not Found!
      </h1>
    </div>
  )
}

export default ErrorPage
